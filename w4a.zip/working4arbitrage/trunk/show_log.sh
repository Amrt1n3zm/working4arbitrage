#!/usr/bin/env bash

tail /tmp/w4a_download.log -n 50 | less
